#include <stdio.h>
#include <stdlib.h>

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

struct node *searchNode()
{
    struct node *temp;
    int search;

    if(START == NULL)
        return(NULL);
    else
    {
        printf("Enter any value to be search:");
        scanf("%d", &search);

        temp = START;

        while(temp != NULL)
        {
            if(temp->info == search)
                return(temp);

            temp = temp->next;
        }
        return(NULL);
    }
};

void insertAtStart()
{
    struct node *temp;

    temp = createNode();

    temp->prev = NULL;

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = START;

    START = temp;
}

void insertAtLast()
{
    struct node *temp, *temp1;

    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = NULL;

    if(START == NULL)
    {
        temp->prev = NULL;
        START = temp;
    }
    else
    {
        temp1 = START;

        while(temp1->next != NULL)
        {
            temp1 = temp1->next;
        }
        temp->prev = temp1;
        temp1->next = temp;
    }
}

void insertAfterNode()
{
    struct node *temp, *ptr;

    ptr = searchNode();

    if(ptr == NULL)
        printf("Invalid Search. List is Empty.");

    else
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->prev = ptr;
        temp->next = ptr->next;

        if(ptr->next != NULL)
            ptr->next->prev = temp;

        ptr->next = temp;
    }
}

void viewList()
{
    struct node *T;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        T = START;

        while(T != NULL)
        {
            printf("%d ", T->info);
            T = T->next;
        }
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Insert at Start.");
        printf("\n2. Insert at Last.");
        printf("\n3. Insert after a Node.");
        printf("\n4. Viewlist.");
        printf("\n5. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertAtStart();
            break;

        case 2:
            insertAtLast();
            break;

        case 3:
            insertAfterNode();
            break;

        case 4:
            viewList();
            break;

        case 5:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
