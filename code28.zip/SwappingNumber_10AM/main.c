#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 5, b = 4;

    printf("Before swapping the value of a=%d and b=%d.\n\n", a, b);

    //XOR

    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    printf("After swapping the value of a=%d and b=%d.", a, b);

    return 0;
}
