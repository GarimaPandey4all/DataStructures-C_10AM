#include <stdio.h>
#include <stdlib.h>

int findSingleNumber(int arr[], int n)
{
    int ans = 0;

    for(int i=0; i<n; i++)
    {
        ans = ans ^ arr[i];
    }
    return ans;
}

int main()
{
    int arr[] = {1, 2, 3, 2, 1, 3, 3};

    int singleNumber;

    singleNumber = findSingleNumber(arr, 7);

    printf("Odd Number Occurrence:%d",singleNumber);

    return 0;
}
