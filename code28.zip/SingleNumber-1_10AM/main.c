#include <stdio.h>
#include <stdlib.h>

int findSingleNumber(int arr[], int n)
{
    int count = 0;

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(arr[i] == arr[j])
                count++;
        }
        if((count%2) != 0)
        {
            return arr[i];
        }
    }
    return -1;
}

int main()
{
    int arr[] = {1, 2, 3, 2, 1};

    int singleNumber;

    singleNumber = findSingleNumber(arr, 5);

    printf("Odd Number Occurrence:%d",singleNumber);

    return 0;
}
