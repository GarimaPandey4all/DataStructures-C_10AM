#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter any Character:");
    scanf("%c", &ch);

    if((ch & 0b00100000) == 0)
        printf("Upper Case\n");

    if((ch & 0b00100000) == 0b00100000)
        printf("Lower Case\n");

//    if(ch >= 65 &&  ch <= 90)
//        printf("Upper Case\n");
//    if(ch >= 97 && ch <= 122)
//        printf("Lower Case\n");

    return 0;
}
