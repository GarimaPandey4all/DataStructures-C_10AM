#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], n, i, j, temp, min;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
        scanf("%d", &array[i]);

    printf("Unsorted Array:\n");
    for(i=0; i<n; i++)
        printf("%d  ", array[i]);


    /*       0  1  2  3  4  5
            10, 3, 1, 2, 5, 6

            1, 3, 10, 2, 5, 6
            1, 2, 10, 3, 5, 6
            1, 2, 3, 10, 5, 6
            1, 2, 3, 5, 10, 6
            1, 2, 3, 5, 6, 10


            5, 4, 3, 2, 1

    */

    //Logic Selection Sort
    for(i=0; i<n-1; i++) //n=6 ; i<5
    {
        min = i; // min = 0
        for(j=i+1; j<n; j++) // j = 1, 2, 3, 4, 5
        {
            if(array[j] < array[min]) // 3 < 10 , 1 < 3, 2 < 1
            {
                min = j; // min = 1, 2
            }
        }

        //Swapping

        temp = array[i];
        array[i] = array[min];
        array[min] = temp;
    }

    printf("\n\nSorted Selection Sort Array:\n");
    for(i=0; i<n; i++)
        printf("%d  ", array[i]);

    return 0;
}
