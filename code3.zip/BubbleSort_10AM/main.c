#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i, j, temp, n;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
        scanf("%d", &array[i]);

    printf("Unsorted Array:\n");
    for(i=0; i<n; i++)
        printf("%d  ", array[i]);


    /*
       i = 0 < n-1: 4
        0  1  2  3  4
        5, 4, 3, 2, 1
        4, 5, 3, 2, 1
        4, 3, 5, 2, 1
        4, 3, 2, 5, 1
        4, 3, 2, 1, 5

        i = 1;

        4, 3, 2, 1, 5
        3, 4, 2, 1, 5
        3, 2, 4, 1, 5
        3, 2, 1, 4, 5

        i = 2;
        3, 2, 1, 4, 5
        2, 3, 1, 4, 5
        2, 1, 3, 4, 5

        i = 3;

        2, 1, 3, 4, 5
        1, 2, 3, 4, 5
    */

    //Logic for Bubble Sort
    for(i=0; i<n-1; i++)
    {
        for(j=0; j<n-1-i; j++) //j < 5 - 1 - 1 = 3
        {
            if(array[j] > array[j+1]) //(5 > 4)
            {
                //Swapping
                temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }

    printf("\n\nBubble Sorted Array is:\n");
    for(i=0; i<n; i++)
        printf("%d  ", array[i]);

    return 0;
}
