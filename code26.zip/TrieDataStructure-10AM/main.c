#include <stdio.h>
#include <stdlib.h>
#define N 26

struct TrieNode
{
    char data;
    struct TrieNode *children[N];
    int isleaf;
};

struct TrieNode *createNode(char data)
{
    struct TrieNode *n;

    n = (struct TrieNode *)malloc(sizeof(struct TrieNode));

    for(int i=0; i<N; i++)
        n->children[i] = NULL;

    n->data = data;
    n->isleaf = 0;

    return(n);
};


struct TrieNode *insert(struct TrieNode *root, char *word)
{
    struct TrieNode *temp;

    temp = root;

    for(int i=0; word[i] != '\0'; i++)
    {
        int index = (int)word[i] - 'a';

        if(temp->children[index] == NULL)
        {
            temp->children[index] = createNode(word[i]);
        }
        temp = temp->children[index];
    }
    temp->isleaf = 1;
    return(root);
};


int search(struct TrieNode *root, char *word)
{
    struct TrieNode *temp = root;

    for(int i=0; word[i] != '\0'; i++)
    {
        int position = (int)word[i] - 'a';

        if(temp->children[position] == NULL)
        {
            return 0;
        }
        temp = temp->children[position];
    }

    if(temp != NULL && temp->isleaf == 1)
        return 1;

    return 0;
}

void Delete(struct TrieNode *n)
{
    for(int i=0; i<N; i++)
    {
        if(n->children[i] != NULL)
            Delete(n->children[i]);
        else
            continue;
    }
    free(n);
}

void display(struct TrieNode *root)
{
    if(!root)
    {
        return;
    }
    struct TrieNode *temp = root;

    printf("%c ", temp->data);

    for(int i=0; i<N; i++)
        display(temp->children[i]);
}

void printSearch(struct TrieNode *root, char *word)
{
    printf("\nSearching for %s:", word);
    if(search(root, word) == 0)
        printf("Not Found\n");
    else
        printf("Found\n");
}

int main()
{
    struct TrieNode *root;

    root = createNode('\0');

    root = insert(root, "hello");
    root = insert(root, "hi");

    printSearch(root, "hi");
    printSearch(root, "hen");

    printf("\nTrie Data structure is:\n");
    display(root);

    root = insert(root, "hen");
    root = insert(root, "tea");

    printSearch(root, "hen");
    printSearch(root, "tea");

    Delete(root);

    root = createNode('\0');

    root = insert(root, "brain");
    root = insert(root, "hey");

    printSearch(root, "brain");
    printSearch(root, "hey");

    return 0;
}
