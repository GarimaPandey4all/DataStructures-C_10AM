#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, array[10];

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n", n);
    for(i=0; i<n; i++)
        scanf("%d", &array[i]);

    printf("Unsorted Array:\n");
    for(i=0; i<n; i++)
        printf("%d  ", array[i]);

    quicksort(array, 0, n-1); //function calling

    printf("\nSorted Array:\n");
    for(i=0; i<n; i++)
        printf("%d  ", array[i]);

    return 0;
}

//function definition
void quicksort(int array[10], int first, int last)
{
    int pivot, i, j, temp;

    if(first < last)
    {
        pivot = first;
        i = first;
        j = last;

        while(i < j)
        {
            while(array[pivot] >= array[i] && i<last)
                i++;

            while(array[pivot] < array[j])
                j--;

            if(i < j)
            {
                temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        //swapping of pivot value
        temp = array[pivot];
        array[pivot] = array[j];
        array[j] = temp;

        //recursively sort sub-arrays
        quicksort(array, 0, j-1); //left sub-array
        quicksort(array, j+1, last);

    }
}
