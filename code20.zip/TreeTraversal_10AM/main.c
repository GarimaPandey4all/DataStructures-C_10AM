#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *left;
    struct node *right;
};

struct node *createNode(int value)
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

void inorder(struct node *root)
{
    if(root != NULL)
    {
        inorder(root->left);
        printf("%d  ", root->info);
        inorder(root->right);
    }
}

void preorder(struct node *root)
{
    if(root != NULL)
    {
        printf("%d  ", root->info);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(struct node *root)
{
    if(root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        printf("%d  ", root->info);
    }
}

struct node *insertLeft(struct node *root, int value)
{
    root->left = createNode(value);
    return root->left;
};

struct node *insertRight(struct node *root, int value)
{
    root->right = createNode(value);
    return root->right;
};

int main()
{
    struct node *root = createNode(1);

    insertLeft(root, 12);
    insertRight(root, 9);

    insertLeft(root->left, 5);
    insertRight(root->left, 6);

    insertLeft(root->right, 3);
    insertRight(root->right, 7);

    printf("PreOrder Traversal:\n");
    preorder(root);

    printf("\nInOrder Traversal:\n");
    inorder(root);

    printf("\nPostOrder Traversal:\n");
    postorder(root);

    return 0;
}
