#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i, n, maxElement = 0;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in an Array are:");
    for(i=0; i<n; i++)
    {
        printf("%d  ", array[i]);
    }

    //Logic to find leaders in an array
    printf("\nLeaders in an array are:");
    for(i=n-1; i>=0; i--)
    {
        if(array[i] > maxElement)
        {
            printf("%d  ", array[i]);
            maxElement = array[i];
        }
    }

    return 0;
}
