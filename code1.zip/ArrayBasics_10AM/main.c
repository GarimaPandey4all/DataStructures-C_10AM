#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[5] = {10, 20, 30, 40, 50};
    //Traditional way

    int array[5];

    for(int i=0; i<5; i++)
    {
        scanf("%d", &array[i]);
    }

    int array[] = {10, 20, 30, 40, 50};
    //compile time initialization/declaration

    int array[2][3][4];

    return 0;
}
