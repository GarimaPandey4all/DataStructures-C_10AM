#include <stdio.h>
#include <stdlib.h>

//4, 13, 26, 37, 58, 90

//search = 37

int main()
{
    int array[10], i, n, search;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in an Array are:");
    for(i=0; i<n; i++)
    {
        printf("%d  ", array[i]);
    }

    printf("\nEnter any value to be search:");
    scanf("%d", &search);

    //Logic to search
    for(i=0; i<n; i++)
    {
        if(array[i] == search)
        {
            printf("%d value found at location %d.", search, i+1);
            break;
        }
    }

    if(i==n)
        printf("%d value is not found.", search);

    return 0;
}
