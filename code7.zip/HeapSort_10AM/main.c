#include <stdio.h>
#include <stdlib.h>

int main()
{
    int heap[10], i, j, n, temp, c, root;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
        scanf("%d", &heap[i]);

    printf("\nHeap Array:\n");
    for(i=0; i<n; i++)
        printf("%d  ", heap[i]);

    /*
        35, 50, 15, 25, 80, 20, 90, 45
        50, 35, 15, 25, 80, 20, 90, 45
        50, 80, 15, 25, 35, 20, 90, 45
        80, 50, 15, 25, 35, 20, 90, 45
        80, 50, 20, 25, 35, 15, 90, 45
        80, 50, 90, 25, 35, 15, 20, 45
        90, 50, 80, 25, 35, 15, 20, 45
        90, 50, 80, 45, 35, 15, 20, 25

    */

    //Logic for heap sort
    for(i=1; i<n; i++) //i = 1, 2, 3, 4, 5, 6, 7
    {
        c = i; // c = 1, 2, 3, 4, 5, 6, 7

        do
        {
            root = (c-1)/2; // 0, 0, 1, 0, 1, 0, 2, 0, 2, 0, 3, 1, 0

            if(heap[root] < heap[c]) //Create Max heap array
            {
                temp = heap[root];
                heap[root] = heap[c];
                heap[c] = temp;
            }
            c = root; // 0, 0, 1, 0, 1, 0, 2, 0, 2, 0, 3, 1, 0
        }while(c != 0);
    }

    printf("\nMax Heap Array is:\n");
    for(i=0; i<n; i++)
        printf("%d  ", heap[i]);

    //sort heap array
    for(j=n-1; j>=0; j--) //j = 7, 6
    {
        //swap maximum element with rightmost leaf element
        temp = heap[0];
        heap[0] = heap[j];
        heap[j] = temp;

        root = 0;

        /*
            90, 50, 80, 45, 35, 15, 20, 25
            25, 50, 80, 45, 35, 15, 20, 90

        */

        do
        {
            //left node of element
            c = 2 * root + 1; // c= 1, 5

            if(heap[c] < heap[c+1] && c < j - 1)
                c++; // c = 2, 6

            //rearrange to max heap array
            if(heap[root] < heap[c] && c<j)
            {
                temp = heap[root];
                heap[root] = heap[c];
                heap[c] = temp;
            }

            root = c; // root = 2, 6
        }while(c < j);
    }

    printf("\nSorted Array:\n");
    for(i=0; i<n; i++)
        printf("%d  ", heap[i]);

    return 0;
}
