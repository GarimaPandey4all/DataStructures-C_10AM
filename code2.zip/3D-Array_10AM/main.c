#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[5][5][5], i, j, k, n1, n2, n3;

    printf("Enter any number of rows:");
    scanf("%d", &n1);

    printf("Enter any number of columns:");
    scanf("%d", &n2);

    printf("Enter any number of columns:");
    scanf("%d", &n3);

    printf("Enter values in 3D-Array:");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            for(k=0; k<n3; k++)
            scanf("%d", &array[i][j][k]);
        }
    }

    printf("3D-Array is:\n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            for(k=0; k<n3; k++)
           printf("%d\t", array[i][j][k]);
        }
    }

    return 0;
}
