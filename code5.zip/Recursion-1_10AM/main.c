#include <stdio.h>
#include <stdlib.h>

/*
    first n natural numbers: sum

    3 = 1 + 2 + 3 = 6
*/

int main()
{
    int x;
    x = func(3);
    printf("%d", x);

    return 0;
}

int func(int a)
{
    int sum;
    if(a == 1) //base case
        return(a);
    sum = a + func(a-1); //func(a-1): recursive call
    return(sum);
}
