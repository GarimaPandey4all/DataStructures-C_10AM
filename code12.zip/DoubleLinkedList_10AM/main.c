#include <stdio.h>
#include <stdlib.h>

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

struct node *searchNode()
{
    struct node *temp;
    int search;

    if(START == NULL)
        return(NULL);
    else
    {
        printf("Enter any value to be search:");
        scanf("%d", &search);

        temp = START;

        while(temp != NULL)
        {
            if(temp->info == search)
                return(temp);

            temp = temp->next;
        }
        return(NULL);
    }
};

void insertAtStart()
{
    struct node *temp;

    if(START == NULL)
    {
        temp = createNode();

        temp->prev = NULL;

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->next = START;

        START = temp;
    }
    else
        printf("List has first node.");
}

void insertAtLast()
{
    struct node *temp, *temp1;

    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = NULL;

    if(START == NULL)
    {
        temp->prev = NULL;
        START = temp;
    }
    else
    {
        temp1 = START;

        while(temp1->next != NULL)
        {
            temp1 = temp1->next;
        }
        temp->prev = temp1;
        temp1->next = temp;
    }
}

void insertAfterNode()
{
    struct node *temp, *ptr;

    ptr = searchNode();

    if(ptr == NULL)
        printf("Invalid Search. List is Empty.");

    else
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->prev = ptr;
        temp->next = ptr->next;

        if(ptr->next != NULL)
            ptr->next->prev = temp;

        ptr->next = temp;
    }
}

void viewList()
{
    struct node *T;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        T = START;

        while(T != NULL)
        {
            printf("%d ", T->info);
            T = T->next;
        }
    }
}

void viewFirst()
{
    if(START == NULL)
        printf("List is Empty.");
    else
        printf("First Node is:%d", START->info);
}

void viewLast()
{
    struct node *temp;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        temp = START;

        while(temp->next != NULL)
        {
            temp = temp->next;
        }

        printf("Last node is:%d", temp->info);
    }
}

void deleteFirstNode()
{
    struct node *temp;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        temp = START;
        START = START->next;
        START->prev = NULL;
        free(temp);
    }
}

int deleteLastNode()
{
    struct node *temp;

    if(START == NULL)
    {
        printf("List is Empty.");
        return(0);
    }
    else{
        temp = START;

        while(temp->next != NULL)
        {
            temp = temp->next;
        }

        if(START->next == NULL)
            START = NULL;
        else
            temp->prev->next = NULL;

        free(temp);
        return(1);
    }
}

void deleteIntermediateNode()
{
    struct node *ptr;

    ptr = searchNode();

    if(ptr == NULL)
        printf("Invalid Search, List is Empty.");

    else if(ptr->prev == NULL || ptr->next == NULL)
        printf("Invalid Deletion.");

    else
    {
        ptr->prev->next = ptr->next;
        ptr->next->prev = ptr->prev;
        free(ptr);
    }
}


int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Insert at Start.");
        printf("\n2. Insert at Last.");
        printf("\n3. Insert after a Node.");
        printf("\n4. Viewlist.");
        printf("\n5. ViewFirst.");
        printf("\n6. ViewLast.");
        printf("\n7. DeleteFirstNode.");
        printf("\n8. DeleteLastNode.");
        printf("\n9. DeleteIntermediateNode.");
        printf("\n10. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertAtStart();
            break;

        case 2:
            insertAtLast();
            break;

        case 3:
            insertAfterNode();
            break;

        case 4:
            viewList();
            break;

        case 5:
            viewFirst();
            break;

        case 6:
            viewLast();
            break;

        case 7:
            deleteFirstNode();
            break;

        case 8:
            deleteLastNode();
            break;

        case 9:
            deleteIntermediateNode();
            break;

        case 10:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
