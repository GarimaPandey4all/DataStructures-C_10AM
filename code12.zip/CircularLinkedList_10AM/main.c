#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *link;
};

struct node *last = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

void insertToEmpty()
{
    struct node *temp;

    if(last == NULL)
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        last = temp;
        last->link = last;
    }
    else
        printf("List is not Empty.");
}

void viewList()
{
    struct node *temp;

    if(last == NULL)
        printf("List is Empty.");

    else
    {
        temp = last->link;
        do
        {
            printf("%d  ", temp->info);
            temp = temp->link;
        }while(temp != last->link);
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Insert in an Empty list.");
        printf("\n2. ViewList.");
        printf("\n3. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertToEmpty();
            break;

        case 2:
            viewList();
            break;

        case 3:
            exit(0);

        default:
            printf("Invalid Choice.");

        }
    }

    return 0;
}
